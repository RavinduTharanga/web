$("#home_1").click(function () {
    //animate html body and use jQuery scrollTop
    $('html, body').animate({
        scrollTop: $("#home_11").offset().top
    }, 1000);
});

$("#home_2").click(function () {
    //animate html body and use jQuery scrollTop
    $('html, body').animate({
        scrollTop: $("#home_22").offset().top -20
    }, 1000);
});
$("#home_3").click(function () {
    //animate html body and use jQuery scrollTop
    $('html, body').animate({
        scrollTop: $("#home_33").offset().top -20
    }, 1000);
});
$("#home_4").click(function () {
    //animate html body and use jQuery scrollTop
    $('html, body').animate({
        scrollTop: $("#home_44").offset().top -20
    }, 1000);
});


